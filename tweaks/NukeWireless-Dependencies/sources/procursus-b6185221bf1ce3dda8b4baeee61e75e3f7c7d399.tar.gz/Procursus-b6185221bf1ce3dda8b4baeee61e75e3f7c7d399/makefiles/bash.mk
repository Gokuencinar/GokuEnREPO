ifneq ($(PROCURSUS),1)
$(error Use the main Makefile)
endif

ifeq (,$(findstring darwin,$(MEMO_TARGET)))
STRAPPROJECTS   += bash
else # ($(MEMO_TARGET),darwin-\*)
SUBPROJECTS     += bash
endif # ($(MEMO_TARGET),darwin-\*)
BASH_VERSION    := 5.2.21
BASH_PATCHLEVEL := 0
DEB_BASH_V      ?= $(BASH_VERSION)

bash-setup: setup
	$(call DOWNLOAD_FILES,$(BUILD_SOURCE),https://ftpmirror.gnu.org/bash/bash-$(BASH_VERSION).tar.gz{$(comma).sig})
	$(call PGP_VERIFY,bash-$(BASH_VERSION).tar.gz)
	$(call EXTRACT_TAR,bash-$(BASH_VERSION).tar.gz,bash-$(BASH_VERSION),bash)
	mkdir -p $(BUILD_STAGE)/bash/$(MEMO_PREFIX)/bin
ifeq (,$(findstring darwin,$(MEMO_TARGET)))
ifneq (,$(MEMO_PREFIX))
	sed -i 's|"/etc/profile|"$(MEMO_PREFIX)/etc/profile|' $(BUILD_WORK)/bash/pathnames.h.in
endif
BASH_CONFIGURE_ARGS := ac_cv_c_stack_direction=-1 \
	ac_cv_func_mmap_fixed_mapped=yes \
	ac_cv_func_setvbuf_reversed=no \
	ac_cv_func_strcoll_works=yes \
	ac_cv_func_working_mktime=yes \
	ac_cv_prog_cc_g=no \
	ac_cv_rl_version=8.0 \
	ac_cv_type_getgroups=gid_t \
	bash_cv_dev_fd=absent \
	bash_cv_dup2_broken=no \
	bash_cv_func_ctype_nonascii=no \
	bash_cv_func_sigsetjmp=present \
	bash_cv_func_strcoll_broken=yes \
	bash_cv_job_control_missing=present \
	bash_cv_must_reinstall_sighandlers=no \
	bash_cv_sys_named_pipes=present \
	bash_cv_sys_siglist=yes \
	gt_cv_int_divbyzero_sigfpe=no
endif

ifneq ($(wildcard $(BUILD_WORK)/bash/.build_complete),)
bash:
	@echo "Using previously built bash."
else
bash: bash-setup ncurses readline gettext
	cd $(BUILD_WORK)/bash && ./configure -C \
		$(DEFAULT_CONFIGURE_FLAGS) \
		--disable-nls \
		--with-installed-readline=yes \
		CFLAGS="$(CFLAGS) -DSSH_SOURCE_BASHRC" \
		$(BASH_CONFIGURE_ARGS) \
		bash_cv_getcwd_malloc=yes \
		READLINE_LIBS="-lreadline"
	+$(MAKE) -C $(BUILD_WORK)/bash \
		TERMCAP_LIB=-lncursesw \
		HISTORY_LDFLAGS="" \
		READLINE_LDFLAGS=""
	+$(MAKE) -C $(BUILD_WORK)/bash install \
		DESTDIR="$(BUILD_STAGE)/bash"
ifneq ($(MEMO_SUB_PREFIX),)
	$(LN_S) $(MEMO_PREFIX)$(MEMO_SUB_PREFIX)/bin/bash $(BUILD_STAGE)/bash/$(MEMO_PREFIX)/bin/bash
endif
	$(call AFTER_BUILD)
endif

bash-package: bash-stage
	# bash.mk Package Structure
	rm -rf $(BUILD_DIST)/bash

	# bash.mk Prep bash
	cp -a $(BUILD_STAGE)/bash $(BUILD_DIST)

	# bash.mk Sign
	$(call SIGN,bash,general.xml)

	# bash.mk Make .debs
	$(call PACK,bash,DEB_BASH_V)

	# bash.mk Build cleanup
	rm -rf $(BUILD_DIST)/bash

.PHONY: bash bash-package
